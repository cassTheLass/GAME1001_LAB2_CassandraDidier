#include <iostream>
#include "classes.h"
#pragma once







// -----------DWARF-----------------------------------------------------------

// Mutators
void Dwarf::SetNameMod(std::string name)
{
	this->nameMod = name;
};


void Dwarf::SetHealthMod(int healthMod)
{
	this->healthMod = healthMod;
};


void Dwarf::SetAttackMod(int attackMod)
{
	this->attackMod = attackMod;
};


// Accessors
std::string Dwarf::GetNameMod()
{
	return nameMod;
};

int Dwarf::GetHealthMod()
{
	return healthMod;
};

int Dwarf::GetAttackMod()
{
	return attackMod;
};

// Other functions
void Dwarf::DisplayInformation()
{
	std::cout << "Dwarves are a sturdy bunch who live in the mountains. \n";
	std::cout << "+" << healthMod << " health\n+" << attackMod << " attack\n";
};

// ----------------------------------------------------------------------


// -----------HUMAN-----------------------------------------------------------

// Mutators
void Human::SetNameMod(std::string name)
{
	this->nameMod = name;
};


void Human::SetHealthMod(int healthMod)
{
	this->healthMod = healthMod;
};


void Human::SetAttackMod(int attackMod)
{
	this->attackMod = attackMod;
};


// Accessors
std::string Human::GetNameMod()
{
	return nameMod;
};

int Human::GetHealthMod()
{
	return healthMod;
};

int Human::GetAttackMod()
{
	return attackMod;
};


// Other functions
void Human::DisplayInformation()
{
	std::cout << "Humans are more common than other races and are pretty average. \n";
	std::cout << "+" << healthMod << " health\n+" << attackMod << " attack\n";
};

// ----------------------------------------------------------------------





// -----------ELF-----------------------------------------------------------

// Mutators
void Elf::SetNameMod(std::string name)
{
	this->nameMod = name;
};


void Elf::SetHealthMod(int healthMod)
{
	this->healthMod = healthMod;
};


void Elf::SetAttackMod(int attackMod)
{
	this->attackMod = attackMod;
};


// Accessors
std::string Elf::GetNameMod()
{
	return nameMod;
};

int Elf::GetHealthMod()
{
	return healthMod;
};

int Elf::GetAttackMod()
{
	return attackMod;
};



// Other functions
void Elf::DisplayInformation()
{
	std::cout << "Elves are fast and masters of stealth and attack. \n";
	std::cout << "+" << healthMod << " health\n+" << attackMod << " attack\n";
};

// ----------------------------------------------------------------------

