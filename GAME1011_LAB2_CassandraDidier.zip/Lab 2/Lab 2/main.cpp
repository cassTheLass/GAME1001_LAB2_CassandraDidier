#include <iostream>
#include "classes.h"



void SelectRace()
{
	std::cout << "Would you like to select this race?\n";
	std::cout << "[1] Yes\n[2] Back";
};



int main()
{
	// Making The Races and Weapon
	Dwarf dwarf(" of Mahakam", 15, 5);
	Elf elf(" of the High Order", 5, 15);
	Human human(" the man", 7, 7);
	Weapon weapon1("Battle Axe", "A stumpy but powerful double-edged axe forged in the mountains of Mahakam.", 10);
	Weapon weapon2("Longbow", "An elegant bow for long range attacks.", 6);
	Weapon weapon3("Steel Sword", "An expertly made steel sword ready for battle.", 12);

	enum Races { DWARF, ELF, HUMAN };

	std::cout << "Welcome to Character Creation\n\n";


	short input;

	do {

		std::cout << "Please select a race to learn more about.\n";
		std::cout << "[1] Dwarf\n";
		std::cout << "[2] Human\n";
		std::cout << "[3] Elf\n";
		std::cout << "[4] Cancel\n";



		std::cin >> input;

		switch (input)
		{
		case 1:
			input = 0;
			dwarf.DisplayInformation();	// Shows character information
			SelectRace();  // Player can choose this type of character
			std::cin >> input;
			switch (input)
			{
			case 1:
				std::cout << "What would you like to name your character?";
				break;
			case 2:
				break;
			}
			break;
		case 2:
			input = 0;
			human.DisplayInformation();
			SelectRace();
			break;
		case 3:
			input = 0;
			elf.DisplayInformation();
			SelectRace();
			break;
		default:
			break;
		}

	} while (input != (1 || 2 || 3));



	//View all characters
	//create new one

	//Choose your Race
	//Choose your Name
	//Choose your Weapon

	//Show all stats
	//Save

	//View all characters
	//delete a character


	return 0;
}