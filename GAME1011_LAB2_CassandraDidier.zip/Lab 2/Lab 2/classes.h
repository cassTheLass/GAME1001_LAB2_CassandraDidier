﻿#include <iostream>
#pragma once





// ----------------------------------------------------------------------WEAPON

class Weapon
{
private:
	std::string name;
	std::string description;
	int damage;
	//special abilities stored in an array

public:
	Weapon()				//Default thing because no parameters
	{
		SetName("");
		SetDesc("");
		int damage{};
	}

	Weapon(std::string name, std::string description, int damage)
	{
		this->name = name;
		this->description = description;
		this->damage = damage;
	}

	std::string GetName()
	{
		return name;
	};

	std::string SetName(std::string name) 
	{
		this->name = name;
	};

	std::string SetDesc(std::string desc) 
	{
		description = desc;
	};

};
// ----------------------------------------------------------------------WEAPON



// ----------------------------------------------------------------------CHARACTER
class Character
{
private:
	std::string name{};
	int baseHealth{};
	int baseDamage{};
	Weapon weapon;
	
public:

	Character()
	{
		name = "NAME";
		baseHealth = 10;
		baseDamage = 10;
	}

	Character(std::string name, int baseHealth, Weapon weapon)
	{
		this->name = name;
		this->baseHealth = baseHealth;
		this->weapon = weapon;
	}

	void SetName(std::string name)
	{
		this->name = name;
	}

	void DisplayInformation()
	{
		std::cout << "CHARACTER INFORMATION\n";
		std::cout << "---------------------\n";
		std::cout << "Name: " << name << std::endl;
		std::cout << "Health: " << baseHealth << std::endl;
		std::cout << "Weapon: " << weapon.GetName() << std::endl;
	}


};
// ----------------------------------------------------------------------CHARACTER




// ----------------------------------------------------------------------DWARF

class Dwarf : private Character
{
private:
	std::string nameMod;
	int healthMod;
	int attackMod;

public:
	Dwarf(std::string nameMod,	int healthMod, int attackMod)
	{
		this->nameMod = nameMod;
		this->healthMod = healthMod;
		this->attackMod = attackMod;
	}

	// Mutators
	void SetNameMod(std::string name);
	void SetHealthMod(int healthMod);
	void SetAttackMod(int attackMod);

	// Accessors
	std::string GetNameMod();
	int GetHealthMod();
	int GetAttackMod();

	// Other functions
	void DisplayInformation();

};
// ----------------------------------------------------------------------DWARF




// ----------------------------------------------------------------------HUMAN

class Human
{
private:
	std::string nameMod;
	int healthMod;
	int attackMod;

public:
	Human(std::string nameMod, int healthMod, int attackMod)
	{
		this->nameMod = nameMod;
		this->healthMod = healthMod;
		this->attackMod = attackMod;
	}

	// Mutators
	void SetNameMod(std::string name);
	void SetHealthMod(int healthMod);
	void SetAttackMod(int attackMod);

	// Accessors
	std::string GetNameMod();
	int GetHealthMod();
	int GetAttackMod();


	// Other functions
	void DisplayInformation();

};
// ----------------------------------------------------------------------HUMAN



// ----------------------------------------------------------------------ELF

class Elf
{
private:
	std::string nameMod;
	int healthMod;
	int attackMod;

public:
	Elf(std::string nameMod, int healthMod, int attackMod)
	{
		this->nameMod = nameMod;
		this->healthMod = healthMod;
		this->attackMod = attackMod;
	}

	// Mutators
	void SetNameMod(std::string name);
	void SetHealthMod(int healthMod);
	void SetAttackMod(int attackMod);

	// Accessors
	std::string GetNameMod();
	int GetHealthMod();
	int GetAttackMod();

	// Other functions
	void DisplayInformation();
};
// ----------------------------------------------------------------------ELF
